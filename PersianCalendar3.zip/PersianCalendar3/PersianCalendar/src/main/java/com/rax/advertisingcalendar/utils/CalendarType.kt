package com.rax.advertisingcalendar.utils

// So vital, don't ever change names of these
enum class CalendarType {
    SHAMSI, ISLAMIC, GREGORIAN
}
