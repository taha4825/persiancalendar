/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.cepmuvakkit.times.posAlgo;


public class ScreenPosition {

    public int x;
    public int y;

    public ScreenPosition() {
    }

}
